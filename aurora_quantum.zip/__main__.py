
import sys
sys.path.insert(0, sys.path[0])  # Ensure ZIP is in path
from aurora import SelfModifyingAurora

if __name__ == "__main__":
    aurora = SelfModifyingAurora()
    try:
        while True:
            prompt = input("Enter a prompt: ")
            if prompt.lower() == 'quit':
                break
            code = aurora.generate_code(prompt)
            print("Generated Code:")
            print(code)
    finally:
        aurora.stop()
