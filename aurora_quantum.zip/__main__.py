
import sys
sys.path.insert(0, sys.path[0])  # Ensure ZIP is in path
from aurora import QuantumCompressedAurora

if __name__ == "__main__":
    print("🌟 Aurora SI - Running from Quantum Compressed ZIP")
    print("=" * 55)
    
    aurora = QuantumCompressedAurora()
    try:
        print("\nCommands:")
        print("- Enter a code prompt to generate code")
        print("- Type 'train' to continue training from web")
        print("- Type 'status' to see training status") 
        print("- Type 'quit' to exit")
        print("-" * 55)
        
        while True:
            prompt = input("\n🔮 Aurora (ZIP)> ").strip()
            
            if prompt.lower() == 'quit':
                break
            elif prompt.lower() == 'train':
                aurora.continue_training_from_web()
            elif prompt.lower() == 'status':
                transitions_count = len(aurora.model.transitions)
                patterns_count = len(aurora.model.pattern_cache)
                history_count = len(aurora.model.training_history)
                print(f"📊 Training Status:")
                print(f"   - Transitions learned: {transitions_count}")
                print(f"   - Patterns cached: {patterns_count}")
                print(f"   - Training history: {history_count} samples")
            elif prompt:
                print("🤖 Generating code...")
                code = aurora.generate_code(prompt)
                print("💻 Generated Code:")
                print("-" * 30)
                print(code)
                print("-" * 30)
            else:
                print("Please enter a prompt or command.")
                
    except KeyboardInterrupt:
        print("\n🛑 Stopping Aurora...")
    finally:
        aurora.stop()
        print("👋 Aurora stopped. Goodbye!")
